#include "kmainwindow.h"

#include <QStringListModel>
#include <QFileDialog>

#include "kregisterui.h"
#include "kexecutor.h"
#include "kinnerregister.h"
#include "kouterregister.h"
#include "kexpressioncalculate.h"
#include "kouterregistermanager.h"

KMainWindow::KMainWindow(QWidget* parent)
	: QMainWindow(parent)
{
	initUi();
	addInnerFunc();
	readIniFile();
	setFuncView();
	(void)connect(m_pRegisterButton, &QPushButton::clicked, this, &KMainWindow::pressRegisterButton);
	(void)connect(m_pLoadDllButton, &QPushButton::clicked, this, &KMainWindow::pressLoadDllButton);
	(void)connect(m_pFuncView, &QListView::clicked, this, &KMainWindow::setExpressionEdit);
	(void)connect(m_pExecuteButton, &QPushButton::clicked, this, &KMainWindow::pressExecuteBtn);
	(void)connect(m_pExecuteExpressionButton, &QPushButton::clicked, this, &KMainWindow::pressExecuteExpressionBtn);
	(void)connect(m_pRegisterWindow, &KRegisterUi::registFuncUpdated, this, &KMainWindow::setFuncView);
}
KMainWindow::~KMainWindow()
{
	delete m_pInnerRegister;
}
void KMainWindow::initUi()
{
	this->setFixedSize(540, 345);
	m_pRegisterWindow = new KRegisterUi(this);
	m_pListLabel = new QLabel("Function List:", this);
	m_pListLabel->move(10, 0);
	m_pExpressionLabel = new QLabel("Expression:", this);
	m_pExpressionLabel->move(230, 0);
	m_pResultLabel = new QLabel("Result:", this);
	m_pResultLabel->move(230, 280);

	m_pResultEdit = new QLineEdit(this);
	m_pResultEdit->setGeometry(280, 285, 250, 20);
	m_pResultEdit->setReadOnly(true);

	m_pLoadDllButton = new QPushButton("Load Dll", this);
	m_pLoadDllButton->setGeometry(230, 310, 75, 25);
	m_pRegisterButton = new QPushButton("Regist Func", this);
	m_pRegisterButton->setGeometry(305, 310, 75, 25);
	m_pExecuteButton = new QPushButton("Execute", this);
	m_pExecuteButton->setGeometry(380, 310, 75, 25);
	m_pExecuteExpressionButton = new QPushButton("Expression", this);
	m_pExecuteExpressionButton->setGeometry(455, 310, 75, 25);
	
	m_pFuncView = new QListView(this);
	m_pFuncView->setGeometry(10, 30, 200, 310);
	m_pFuncView->setEditTriggers(QAbstractItemView::NoEditTriggers);
	m_pModel = new QStringListModel(this);

	m_pExpressionEdit = new QTextEdit(this);
	m_pExpressionEdit->setGeometry(230, 30, 300, 250);
}


void KMainWindow::addInnerFunc()
{
	m_pInnerRegister = new KInnerRegister(); //析构中释放
	m_pInnerRegister->initInner();
}
void KMainWindow::readIniFile()
{
	KOuterRegisterManager::getInstance()->parseIniFile(INI_PATH);
}

void KMainWindow::setFuncView()
{
	KResourceSingleton* singleton = KResourceSingleton::getInstance();
	QStringList data = singleton->getFunctionName();
//	for (auto i : data)
	//	qDebug() << i;
	m_pModel->setStringList(data);
	m_pFuncView->setModel(m_pModel);
	
}
void KMainWindow::setExpressionEdit(const QModelIndex& index)
{
	QString text = index.data(Qt::DisplayRole).toString();
	m_pExpressionEdit->setText(text+"()");
}

void KMainWindow::pressRegisterButton()
{
		m_pRegisterWindow->show();
}
void KMainWindow::pressLoadDllButton()
{
	QString path = QFileDialog::getOpenFileName(this, "Select DLL file", QDir::homePath(), "DLL file (*.dll)");
//	qDebug() << path;
	if (path != "")
	{
		KOuterRegisterManager::getInstance()->addRegister(path);
	}
}
void KMainWindow::pressExecuteBtn()
{
	QString content = m_pExpressionEdit->toPlainText();
	KExecutor executor;
	QString res = executor.executehandle(content);
	m_pResultEdit->setText(res);
}

void KMainWindow::pressExecuteExpressionBtn()
{
	QString content = m_pExpressionEdit->toPlainText();
	KExpressionCalculate calculator;
	double res = calculator.calculate(content);
	m_pResultEdit->setText(QString::number(res));
}
