#ifndef KMAINWINDOW_H_
#define KMAINWINDOW_H_

//---------------------------------------------------------------------
//文件名:kmainwindow.h
//创建者:高珊
//功能描述:主界面各种信号调度
//创建时间:2023/07/19
//Copyright 2023 Kingsoft
//---------------------------------------------------------------------

#include <QMainWindow>
#include <QWidget>
#include <qlayout.h>
#include <Windows.h>
#include <qfiledialog.h>
#include <iostream>

#include "kregister.h"
#include "kbutton.h"
#include "kexpression.h"
#include "kfunction.h"
#include "kglobaldata.h"
#include "kresult.h"
#include "kdialog.h"
//#include "kmath.h"


class KMainWindow :public QMainWindow
{
	Q_OBJECT
public:
	KMainWindow(QWidget* parent =NULL);
	~KMainWindow();


	//布局
	void initWindows();
	void initFunction();

	

public slots:
	void openDialog();
	void choseDialog();
	void openFileDialog();

	//解析配置文件
	void analyzeIni();

signals:
	void addInitFunction();
	void startAnalyze();
	void finishIni();


private:
	QWidget* m_pCenterWidget;
	QVBoxLayout* m_pVLayout1;//垂直布局
	QVBoxLayout* m_pVLayout2;//垂直布局
	QHBoxLayout* m_pHLayout;//水平布局

	KFunction* m_pFunction;
	KExpression* m_pExpression;
	KResult* m_pResult;
	KButton* m_pButton;

	KDialog* m_pDialog;
	QFileDialog* m_pFileDialog;

	KRegister* m_pRegister;

	KMath* m_pSumFunction;
	KMath* m_pAverageFunction;
	KMath* m_pPowerFunction;
	KMath* m_pCombineStrFunction;
};

#endif