#ifndef KGLOBALDATA_H_
#define KGLOBALDATA_H_

//---------------------------------------------------------------------
//文件名:kglobaldata.h
//创建者:高珊
//功能描述:全局变量
//创建时间:2023/07/19
//Copyright 2023 Kingsoft
//---------------------------------------------------------------------

#include <iostream>
#include <qstring.h>
#include <qvector.h>
#include <map>
#include "kmath.h"

/*定义函数指针类型*/
typedef KMath* FunctionPtr;


class KGlobalData
{
public:
	class KRelease
	{
	public:
		KRelease() {}
		~KRelease()
		{
			if (s_globalDataObj)
			{
				delete s_globalDataObj;
			}
		}

	};
	static KGlobalData* getGlobalDataIntance();
	~KGlobalData();

	QVector<QString> getFunctionName();
	void setFunctionName(const QString& functionName);

	QString getExpression();
	void setExpression(const QString& expression);
	void addExpression(const QString& expression);


	QString getResult();
	void setResult(const QString& result);

	QString getAddFunctionName();
	void setAddFunctionName(const QString& addFunctionName);

	QString getFunctionType();
	void setFunctionType(const QString& type);

	QString getDescription();
	void setDescription(const QString& description);

	int getCount();
	void setCount(const int& count);

	QString getDllAddress();
	void setDllAddress(const QString& dllAddress);

	std::map<std::string, std::map<std::string, std::string>> getDllFunction();
	void setDllFunction(const std::map<std::string, std::map<std::string, std::string>>& configData);

	std::map<QString, FunctionPtr> getFunctionMap();
	void setFunctionMap(const QString& name, FunctionPtr func);


private:
	KGlobalData();
	//KGlobalData(const KGlobalData& other) {}
	static KGlobalData* s_globalDataObj;
	static KRelease s_gc;

	QVector<QString> m_functionName;//函数名
	QString m_expression;//函数描述
	QString m_result;//函数结果
	QString m_addFunctionName;//要添加的函数名
	QString m_functionType;
	QString m_description;
	int m_count;

	QString m_dllAddress;
	std::map<std::string, std::map<std::string, std::string>>m_configData;


	/*注册函数的容器*/
	std::map<QString, FunctionPtr> m_functionMap;
};



#endif
