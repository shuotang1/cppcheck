#include "kresourcesingleton.h"  
KResourceSingleton* KResourceSingleton::s_pInstance = nullptr;

KResourceSingleton::KResourceSingleton()
{
}

KResourceSingleton::~KResourceSingleton()
{
	delete s_pInstance;
}
KResourceSingleton* KResourceSingleton::getInstance() 
{
	if (s_pInstance == nullptr) 
	{
		s_pInstance = new KResourceSingleton();
	}
	return s_pInstance;
}

void KResourceSingleton::addFunction(const QString& functionName, VoidFuncPtr funcptr) 
{
	m_functionMap[functionName] = funcptr;
}

VoidFuncPtr KResourceSingleton::getFunctionPointer(const QString& functionName) const
{
	auto it = m_functionMap.find(functionName);
	if (it != m_functionMap.end()) 
	{
		return it.value();
	}
	return nullptr;
}

QStringList KResourceSingleton::getFunctionName() const
{
	QStringList functionNameList;
	for (QMap<QString, VoidFuncPtr>::const_iterator it = m_functionMap.constBegin(); it != m_functionMap.constEnd(); ++it) 
	{
		functionNameList.append(it.key());
	}
	return functionNameList;
}

QString KResourceSingleton::getInnerFuncType(const QString& functionName) const
{
	if (m_innerFuncType.contains(functionName)) 
	{
		return m_innerFuncType.value(functionName);
	}
	return "";
}
QString KResourceSingleton::getOuterFuncType(const QString& functionName) const
{
	if (m_outerFuncType.contains(functionName))
	{
		return m_outerFuncType.value(functionName);
	}

	return "";
}
bool KResourceSingleton::isInnerFunc(const QString& functionName)
{
	return m_innerFuncType.contains(functionName);
}

bool KResourceSingleton::isOutFunc(const QString& functionName)
{
	return m_outerFuncType.contains(functionName);
}

void KResourceSingleton::setInnerFuncType(const QString& functionName, const QString& functionType)
{
	m_innerFuncType[functionName] = functionType;
}
void KResourceSingleton::setOuterFuncType(const QString& functionName, const QString& functionType)
{
	m_outerFuncType[functionName] = functionType;
}


void KResourceSingleton::setSelfDefFuncDescription(const QString& functionName, const QString& drescription)
{
	m_selfDefFuncDrescription[functionName] = drescription;
}
QString KResourceSingleton::getSelfDefFuncDescription(const QString& functionName) const
{
	if (m_selfDefFuncDrescription.contains(functionName)) 
	{
		return m_selfDefFuncDrescription.value(functionName);
	}

	return "";
}

