#include "kregister.h"
#include <QStringList>
#include <string>
#include <sstream>  

KRegister::KRegister(QObject* parent)
	:QObject(parent)
{
	
}
KRegister::~KRegister()
{

}


void KRegister::registerFunction(const QString& name, FunctionPtr func)
{
	KGlobalData::getGlobalDataIntance()->setFunctionMap(name, func);
}

void KRegister::registerFunction()
{
	QString functionName = KGlobalData::getGlobalDataIntance()->getAddFunctionName();
	QString expression = KGlobalData::getGlobalDataIntance()->getExpression();
	

	KFunctionCombiner combiner;
	//std::function<int(int, int)> combineFuncPtr = combiner::combineFunction;
	FunctionPtr ptr = combiner.combineFunction(expression);
	combiner.addFunction(functionName, ptr);

	KGlobalData::getGlobalDataIntance()->setFunctionName(functionName);
	emit finishRegister();
}

void  KRegister::registerDll()
{
	std::map<std::string, std::map<std::string, std::string>>configData;
	configData = KGlobalData::getGlobalDataIntance()->getDllFunction();
	unsigned int count = configData.size();//外部导入的函数个数
	//qDebug() << "size=" << count;

	std::string functionName;
	std::string returnType;
	//int paramCount;

	QString dllAddress = KGlobalData::getGlobalDataIntance()->getDllAddress();
	qDebug() << "address=" << dllAddress;
	HMODULE hDll = LoadLibrary(dllAddress.toUtf8().constData());

	if (hDll!=NULL)
	{
		for (unsigned int i = 0; i < count; ++i)
		{
			std::string tempNmae = "Function" +std::to_string(i);
			std::cout << tempNmae << std::endl;
			functionName = configData[tempNmae]["Name"];
			std::cout << "functionName=" << functionName << std::endl;
			returnType = configData[tempNmae]["ReturnType"];
			std::cout << "returnType=" << returnType << std::endl;

			typedef FunctionPtr (_cdecl* DllFunctionPtr)();
			DllFunctionPtr dllFunc = (DllFunctionPtr)GetProcAddress(hDll, functionName.c_str());
			if (dllFunc)
			{
				FunctionPtr function = dllFunc();
				registerFunction(QString::fromStdString(functionName), function);
				KGlobalData::getGlobalDataIntance()->setFunctionName(QString::fromStdString(functionName));
			}
			else
			{
				std::cerr << "Failed to get function pointer" << std::endl;
				FreeLibrary(hDll);
			}

		}
		emit finishDllRegister();
	}
	else
		std::cerr << "Failed to load DLL" << std::endl;
}


void KRegister::analyzeFunction()
{
	QString expression = KGlobalData::getGlobalDataIntance()->getExpression();
	QString functionName = expression.mid(0, expression.indexOf("("));//通过判断第一个函数名是不是字符串类型运算
	if (functionName == "combinestr")
	{
		parseExpressionStr(expression);
	}
	else
	{
		parseExpression(expression.toStdString());
	}

	emit finishResult();
}


void KFunctionCombiner::addFunction(const QString& name, FunctionPtr func)
{
	KGlobalData::getGlobalDataIntance()->setFunctionMap(name, func);
}

FunctionPtr KFunctionCombiner::combineFunction(const QString& expression)
{
	//提取用到的函数名（目前就一个，后面在判断“）”后的标识符等方法）
	QString funcName = expression.mid(0, expression.indexOf("("));

	qDebug() << "funcName:" << funcName;
	FunctionPtr func=NULL;
	std::map<QString, FunctionPtr> functionMap = KGlobalData::getGlobalDataIntance()->getFunctionMap();
	if (functionMap.find(funcName) != functionMap.end())
	{
		func = functionMap[funcName];

	}
	return func;
}

double KRegister::calculate(const double& a, const double& b, const char& op)
{
	if (op == '+')
		return a + b;
	else if (op == '-')
		return a - b;
	else if (op == '*')
		return a * b;
	else if (op == '/')
		return a / b;
	return 0;
}

void KRegister::parseExpression(const std::string& expression)
{
	std::stack<double> operands;
	std::stack<char> operators;
	std::vector<std::string> names;

	std::map<QString, FunctionPtr> functionMap = KGlobalData::getGlobalDataIntance()->getFunctionMap();

	for (unsigned int i = 0; i < expression.length(); i++)
	{
		//QChar ch = expression.at(i);
		//QString indexRight = expression.mid(0, expression.indexOf(")"));
		if (isdigit(expression[i]))
		{
			//判断是不是double类型
			double operand = 0.0;//整数部分
			double operand1 = 0.0;//小数部分
			while (i < expression.length() && (isdigit(expression[i]) || expression[i] == '.'))
			{
				if (expression[i] == '.')
				{
					i++;
					std::string operandStr = "0.";
					while (i < expression.length() && isdigit(expression[i]))
					{
						operandStr += expression[i];
						i++;
					}
					operand1 = std::stod(operandStr);
				}
				else
				{
					operand = operand * 10 + (expression[i] - '0');
					i++;
				}
			}
			i--;
			operands.push(operand + operand1);
		}
		else if (expression[i] == '(')
		{
			operators.push(expression[i]);
		}
		else if (expression[i] == ')')
		{
			//遇到右括号进行计算
			while (!operators.empty() && operators.top() != '(' && !names.empty())
			{
				unsigned int commasNum = 0;
				while (operators.top() == ',')
				{
					commasNum++;
					operators.pop();
				}
				std::vector<std::string> argumentsStr;
				double num = 0.0;
				for (unsigned int j = 0; j < commasNum; j++)
				{
					num = operands.top();
					operands.pop();
					argumentsStr.push_back(std::to_string(num));
				}
				num = operands.top();
				operands.pop();
				argumentsStr.push_back(std::to_string(num));

				std::string name = names[0];
				if (functionMap.find(QString::fromStdString(name)) != functionMap.end())
				{
					FunctionPtr func = functionMap[QString::fromStdString(name)];

					std::stringstream ss;
					for (auto it = argumentsStr.rbegin(); it != argumentsStr.rend(); ++it)
					{
						ss << *it;
						ss << " ";
					}
					std::string combinedStr = ss.str();
					combinedStr = combinedStr.substr(0, combinedStr.length() - 1);
					const char* charPtr = combinedStr.c_str();

					std::string result = func->exportFunction(charPtr);
					operands.push(std::stod(result));
				}
			}
			if (!operators.empty())
				operators.pop();//弹出左括号
		}
		else if (expression[i] == ',' || expression[i] == '+' || expression[i] == '-' || expression[i] == '*' || expression[i] == '/')
		{
			operators.push(expression[i]);
		}
		else
		{
			std::string name = "";
			//函数名拼接
			while (i < expression.length() && expression[i] != '(')
			{
				name += expression[i];
				i++;
			}
			i--;
			names.push_back(name);
		}
	}

	//计算剩余没括号的四则运算
	while (!operators.empty())
	{
		double num1 = operands.top();
		operands.pop();
		double num2 = operands.top();
		operands.pop();
		char op = operators.top();
		operators.pop();
		double result = calculate(num1, num2, op);
		operands.push(result);
	}
	KGlobalData::getGlobalDataIntance()->setResult(QString::number(operands.top()));
}


void KRegister::parseExpressionStr(const QString& expression)
{
	//提取函数名和参数
	QString functionName = expression.mid(0, expression.indexOf("("));
	std::string functionName1 = functionName.toStdString();

	std::cout << "functionName1=" << functionName1;

	QString functionStr = expression.mid(expression.indexOf("(") + 1, expression.indexOf(")") - expression.indexOf("(") - 1);

	// 分割参数字符串  
	QStringList arguments = functionStr.split(",", QString::SkipEmptyParts);

	std::map<QString, FunctionPtr> functionMap = KGlobalData::getGlobalDataIntance()->getFunctionMap();
	if (functionMap.find(functionName) != functionMap.end())
	{
		std::vector<std::string>argumentsStr;
		argumentsStr.clear();
		for (const QString& arg : arguments)
		{
			argumentsStr.push_back(arg.toStdString());
			std::cout << arg.toStdString() << std::endl;
		}

		FunctionPtr func = functionMap[functionName];
		if (!func)
		{
			qDebug() << "stop";
		}

		std::stringstream ss;
		for (const auto& str : argumentsStr)
		{
			ss << str;
		}
		std::string combinedStr = ss.str();
		const char* charPtr = combinedStr.c_str();

		std::string result = func->exportFunction(charPtr);
		std::cout << "result" << result << std::endl;
		KGlobalData::getGlobalDataIntance()->setResult(QString::fromStdString(result));
	}
	else
		std::cerr << "Failed to find function!" << std::endl;
}
