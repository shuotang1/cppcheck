#ifndef MATHFUNCTION_H_
#define MATHFUNCTION_H_

#include <algorithm>
#include <iostream>
#include <string>
#include <vector>
#include "../function/kconvert.h"


#define MATHFUNCTION_EXPORT _declspec(dllexport)


class KMath
{
public:
	virtual ~KMath() {}
	virtual const char* getName() = 0;
	virtual char* exportFunction(const char* args) = 0;
};


class MultiplyFunction :public KMath
{
public:
	const char* getName() override;
	char* exportFunction(const char* args)override;
};


extern "C" MATHFUNCTION_EXPORT KMath * __cdecl multiply()
{
	return new MultiplyFunction();
}

#endif // !KMATHFUNCTION_H_
