#ifndef KRESOURCE_SINGLETON_H  
#define KRESOURCE_SINGLETON_H  
#include <iostream>
#include <QStringList>
#include <QMap>
#include <QSet>
#define MAX_LENGTH 255
#define INI_PATH ("D:/chenhao21/build_debug/WPSOffice-Train/office6/outerdll.ini")
#define INNER_DLL_PATH ("../../../build_debug/WPSOffice-Train/office6/InnerDll.dll")
typedef void(*VoidFuncPtr)();
typedef double(*MathFuncPtr)(double*, int);
typedef bool(*StringFuncPtr)(char*, const char* [],int);
class KResourceSingleton 
{
public:
	static KResourceSingleton* getInstance();

	void addFunction(const QString& functionName, VoidFuncPtr); // 添加函数名和函数指针到map中  
	VoidFuncPtr getFunctionPointer(const QString& functionName) const; // 调用指定函数名对应的函数指针  

	QStringList getFunctionName() const;
	QString getInnerFuncType(const QString& functionName) const;
	QString getOuterFuncType(const QString& functionName) const;
	QString getSelfDefFuncDescription(const QString &name) const;

	void setInnerFuncType(const QString& functionName, const QString& functionType);
	void setOuterFuncType(const QString& functionName, const QString& functionType);
	void setSelfDefFuncDescription(const QString& name,const QString& drescription);

	bool isInnerFunc(const QString& functionName);
	bool isOutFunc(const QString& functionName);

private:
	KResourceSingleton();
	~KResourceSingleton();
private:
	static KResourceSingleton* s_pInstance;
	QMap<QString, VoidFuncPtr> m_functionMap; // 函数名和函数指针的map  
	QMap<QString, QString> m_innerFuncType;
	QMap<QString, QString> m_outerFuncType;
	QMap<QString, QString> m_selfDefFuncDrescription;

};

#endif  

