#ifndef KEXPRESSION_H_
#define KEXPRESSION_H_

//---------------------------------------------------------------------
//文件名:kexpression.h
//创建者:高珊
//功能描述:表达式组件
//创建时间:2023/07/19
//Copyright 2023 Kingsoft
//---------------------------------------------------------------------

#include <QtWidgets/QMainWindow>
#include <qlayout.h>
#include <qlabel.h>
#include <qtextedit.h>

class KExpression:public QWidget
{
	Q_OBJECT

public:
	KExpression(QWidget* parent);
	~KExpression();

public slots:
	void saveExpression();
	void updateExpression();

signals:
	void finishExpression();

public:
	QVBoxLayout* m_pVLayout;//垂直布局
	QLabel* m_pExpressionLabel;//表达式标题
	QTextEdit* m_pExpressionEdite;//表达式输入

};
#endif