#include "inner.h"
#include <cmath>  
#include <string.h>  
INNER_EXPORT double Sum(double* args, int count) {
	double result = 0;
	for (int i = 0; i < count; i++) {
		result += args[i];
	}
	return result;
}

INNER_EXPORT double Power(double* args, int count) {
	if (count != 2) {
		return -1;
	}

	double result = std::pow(args[0], args[1]);
	return result;
}

INNER_EXPORT double Average(double* args , int count) {
	double total = 0;
	for (int i = 0; i < count; i++) {
		total += args[i];
	}
	return total / count;
}

INNER_EXPORT bool Combine(char* dest, const char* src[], int count) {
	if (dest == NULL || src == NULL || count <= 0) {
		return false;
	}

	dest[0] = '\0';  // 初始化目标字符串为空字符串  

	size_t dest_len = strnlen_s(dest, MAX_LENGTH);

	for (int i = 0; i < count; i++) {
		size_t src_len = strnlen_s(src[i], MAX_LENGTH);

		if (dest_len + src_len >= MAX_LENGTH) {
			// 拼接后的字符串长度超过了目标字符串的最大长度  
			return false;
		}

		strcat_s(dest, MAX_LENGTH, src[i]);
		dest_len += src_len;
	}

	return true;
}
