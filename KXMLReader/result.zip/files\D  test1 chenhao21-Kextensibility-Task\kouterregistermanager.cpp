#include "kouterregistermanager.h"
#include <QFile>
#include <QRegularExpression>
KOuterRegisterManager* KOuterRegisterManager::s_pInstance = nullptr;
KOuterRegisterManager::KOuterRegisterManager()
{
}

KOuterRegisterManager* KOuterRegisterManager::getInstance()
{
	if (s_pInstance == nullptr) 
	{
		s_pInstance = new KOuterRegisterManager();
	}
	return s_pInstance;
}
KOuterRegisterManager::~KOuterRegisterManager()
{
	for (auto i : m_pRegisterVrc)
	{
		delete i;
	}
	delete s_pInstance;
}
void KOuterRegisterManager::addRegister(const QString& path)
{
	m_pRegisterVrc.push_back(new KOuterRegister(path));
}
void KOuterRegisterManager::loadAllDll()
{
	for (auto i : m_pRegisterVrc)
	{
		i->loadDll();
	}
}
bool KOuterRegisterManager::registerFuncInDlls(const QString& funcName, const QString& funcType)
{
	for (auto i : m_pRegisterVrc)
	{
		if (i->registerFunc(funcName, funcType))
			return true;
	}
	return false;
}
bool KOuterRegisterManager::registerselfDefDrescription(const QString& funcName, const QString& funcType, const QString& selfDefDrescription)
{
	KResourceSingleton* singleton = KResourceSingleton::getInstance();
	singleton->addFunction(funcName, nullptr);
	singleton->setOuterFuncType(funcName, funcType);
	singleton->setSelfDefFuncDescription(funcName, selfDefDrescription);
	return true;
}

void KOuterRegisterManager::parseIniFile(const QString& filePath)
{
	QFile file(filePath);
	if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
	{
//		qDebug() << "Failed to open file: " << filePath;
		return;
	}

	QTextStream in(&file);
	while (!in.atEnd())
	{
		QString line = in.readLine().trimmed();

		// 匹配 Func 行  
		QRegularExpression funcRegex("Func\\((.*),(.*)\\)");
		QRegularExpressionMatch funcMatch = funcRegex.match(line);
		if (funcMatch.hasMatch())
		{
			QString funcName = funcMatch.captured(1);
			QString funcType = funcMatch.captured(2);
	//		qDebug() << " Func: " << funcName << " " << funcType;
			// 注册函数  
			registerFuncInDlls(funcName, funcType);
		}

		// 匹配 DllPath 行  
		QRegularExpression dllPathRegex("DllPath\\((.*)\\)");
		QRegularExpressionMatch dllPathMatch = dllPathRegex.match(line);
		if (dllPathMatch.hasMatch())
		{
			QString dllPath = dllPathMatch.captured(1);
	//		qDebug() << " DllPath: " << dllPath;
			// 注册并加载 
			addRegister(dllPath);
			loadAllDll();
		}

		// 匹配带有三个参数的 Expression 行  
		QRegularExpression expressionRegex("Expression\\((.*?),(.*?),(.*)\\)");
		QRegularExpressionMatch expressionMatch = expressionRegex.match(line);
		if (expressionMatch.hasMatch())
		{
			QString expressionFuncName = expressionMatch.captured(1);
			QString expressionFuncType = expressionMatch.captured(2);
			QString expressionString = expressionMatch.captured(3);
//			qDebug() << "Expression: " << expressionFuncName << " " << expressionFuncType << " " << expressionString;
			// 注册自定义函数  
			registerselfDefDrescription(expressionFuncName, expressionFuncType, expressionString);
		}
	}

	file.close();
}