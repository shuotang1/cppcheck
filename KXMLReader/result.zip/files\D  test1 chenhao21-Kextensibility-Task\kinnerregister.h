#ifndef KINNERREGISTER_H
#define KINNERREGISTER_H
#include <QDebug>
#include <QLibrary>
#include "kresourcesingleton.h"
class KInnerRegister
{
public:
	KInnerRegister();
	~KInnerRegister();
	void initInner();
private:
	QLibrary* m_pInnerDll = nullptr;
};


#endif //KINNERREGISTER_H
