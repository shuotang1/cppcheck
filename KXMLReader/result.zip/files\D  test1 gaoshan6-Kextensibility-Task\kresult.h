#ifndef KRESULT_H_
#define KRESULT_H_

//---------------------------------------------------------------------
//文件名:kresult.h
//创建者:高珊
//功能描述:结果展示控件
//创建时间:2023/07/19
//Copyright 2023 Kingsoft
//---------------------------------------------------------------------

#include <QtWidgets/QMainWindow>
#include <qlayout.h>
#include <qlabel.h>
#include <QLineEdit>


class KResult :public QWidget
{
	Q_OBJECT
public:
	KResult(QWidget* parent);
	~KResult();

	
	QHBoxLayout* m_pHLayout;
	QLabel* m_pResultLabel;
	QLineEdit* m_pResultEdit;

public slots:
	void showResult();

};


#endif