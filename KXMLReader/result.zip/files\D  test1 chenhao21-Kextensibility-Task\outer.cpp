#include "outer.h"
#include <string.h>  
OUTER_EXPORT double OutMathFunc(double* args, int count)
{
	return 6666;
}
OUTER_EXPORT bool OutStringFunc(char* dest, const char* src[], int count)
{
	char str[] = "OutStringFunc";
	for (size_t i = 0; i < strlen(str)+1; i++)
		dest[i] = str[i];
	return true;
}
