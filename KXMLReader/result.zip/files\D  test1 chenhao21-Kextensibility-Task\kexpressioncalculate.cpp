#include "kexpressioncalculate.h"

#include <QCoreApplication>  
#include <QString>  
#include <QDebug>  
#include <QRegularExpression>  
#include <QRegularExpressionMatch>  
#include <QRegularExpressionMatchIterator>  
#include <QVector>  
#include <QStringList>
#include <iostream>  
#include <QStack>  

#include "kresourcesingleton.h"


double KExpressionCalculate::evaluateFunc(const QString& expression)
{
	// 定义正则表达式  
	QRegularExpression functionRegex("(\\w+)\\((.*)\\)");

	// 匹配函数名和参数  
	QRegularExpressionMatch match = functionRegex.match(expression);

	if (match.hasMatch())
	{
		QString functionName = match.captured(1);
		QString parametersString = match.captured(2);

		// 分割参数  
	//	qDebug() << parametersString;
		QStringList parameters = separateParams(parametersString);
	//	qDebug() << parameters;
			// 递归调用该函数，计算每个参数的值  
		QVector<double> values;
		double args[MAX_LENGTH];
		int argSize = 0;
		for (const QString& param : parameters) 
		{
			args[argSize] = calculate(param.trimmed());
			argSize++;
		}

		// 根据函数名进行相应的计算  
		MathFuncPtr mathFuncPtr = (MathFuncPtr)KResourceSingleton::getInstance()->getFunctionPointer(functionName);
		if (mathFuncPtr == nullptr)
			return 6666.6666;
		return mathFuncPtr(args, argSize);
	}

	// 如果表达式不匹配任何函数形式，且是数字，则直接返回该数字  
	if (expression[0].isDigit())
	{
		return expression.toDouble();
	}

	// 如果表达式不匹配上述任何形式，返回0.0  
	return 0.0;
}

QStringList KExpressionCalculate::separateParams(const QString& paramsStr) 
{
	QStringList params;
	QString currentParam = "";
	int parenthesesCount = 0;

	for (QChar c : paramsStr)
	{
		if (c == '(') 
		{
			parenthesesCount++;
		}
		else if (c == ')') 
		{
			parenthesesCount--;
		}

		if (c == ',' && parenthesesCount == 0) 
		{
			params.append(currentParam);
			currentParam = "";
		}
		else 
		{
			currentParam += c;
		}
	}

	params.append(currentParam);
	return params;
}


double KExpressionCalculate::performOperation(double num1, double num2, char op) 
{
	if (op == '+')
		return num1 + num2;
	else if (op == '-')
		return num1 - num2;
	else if (op == '*')
		return num1 * num2;
	else if (op == '/')
		return num1 / num2;
	else
		return 0.0;
}

QString KExpressionCalculate::getFirstFunc(const QString& expression) const
{
	QString result;
	int leftCount = 0;
	int rightCount = 0;

	for (int i = 0; i < expression.length(); i++) 
	{
		QChar ch = expression[i];
		result += ch;
		if (ch == '(')
		{
			leftCount++;

		}
		if (ch == ')') 
		{
			rightCount++;
		}
		if (leftCount > 0 && leftCount == rightCount) 
		{
			break;
		}

	}
	return result;
}

QString KExpressionCalculate::getFirstNumber(const QString& text) const
{
	// 创建一个正则表达式模式，用于匹配第一个整数或小数  
	QRegExp regex("\\d+(\\.\\d+)?");
	// 在给定的字符串中搜索第一个匹配项  
	int index = regex.indexIn(text);
	// 如果找到匹配项，则返回匹配到的结果  
	if (index != -1) 
	{
		return regex.cap();
	}
	// 如果没有找到匹配项，则返回空字符串  
	return "";
}

double KExpressionCalculate::calculate(const QString& expression) 
{
	if (expression == "")
		return 0;
	QStack<double> num_stack;
	QStack<char> op_stack;
	int precedence[256] = { 0 };
	precedence['+'] = 1;
	precedence['-'] = 1;
	precedence['*'] = 2;
	precedence['/'] = 2;

	for (int i = 0; i < expression.length(); i++)
	{
		QChar ch = expression[i];

		if (ch.isDigit()) {
			/*double num = ch.digitValue();
			while (i + 1 < expression.length() && expression[i + 1].isDigit())
			{
				num = num * 10 + expression[i + 1].digitValue();
				i++;
			}*/
			QString num = getFirstNumber(expression.mid(i));
			i = i + num.length() - 1;
			num_stack.push(num.toDouble());
		}
		else if (ch.isLetter()) 
		{
			QString funcStr = getFirstFunc(expression.mid(i));
	//		qDebug() << expression.mid(i);
	//		qDebug() << funcStr;
			double val = evaluateFunc(funcStr);
			num_stack.push_back(val);
			i += funcStr.length() - 1;
			//qDebug() << expression[i];
		}
		else if (ch == '(') 
		{
			op_stack.push(ch.toLatin1());
		}
		else if (ch == ')') 
		{
			while (!op_stack.empty() && op_stack.top() != '(') 
			{
				char op = op_stack.top();
				op_stack.pop();
				double num2 = num_stack.top();
				num_stack.pop();
				double num1 = num_stack.top();
				num_stack.pop();
				double result = performOperation(num1, num2, op);
				num_stack.push(result);
			}
			op_stack.pop();
		}
		else if (ch == '+' || ch == '-' || ch == '*' || ch == '/')
		{
			while (!op_stack.empty() && op_stack.top() != '(' && precedence[op_stack.top()] >= precedence[ch.toLatin1()]) 
			{
				char op = op_stack.top();
				op_stack.pop();
				double num2 = num_stack.top();
				num_stack.pop();
				double num1 = num_stack.top();
				num_stack.pop();
				double result = performOperation(num1, num2, op);
				num_stack.push(result);
			}
			op_stack.push(ch.toLatin1());
		}
	}

	while (!op_stack.empty()) 
	{
		char op = op_stack.top();
		op_stack.pop();
		double num2 = num_stack.top();
		num_stack.pop();
		double num1 = num_stack.top();
		num_stack.pop();
		double result = performOperation(num1, num2, op);
		num_stack.push(result);
	}

	return num_stack.top();
}

