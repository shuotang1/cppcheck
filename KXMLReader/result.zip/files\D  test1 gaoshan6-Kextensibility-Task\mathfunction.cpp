#include "mathfunction.h"
#include <sstream>  
#include <cstring>  


const char* MultiplyFunction::getName()
{
	return "multiply";
}
char* MultiplyFunction::exportFunction(const char* args)
{
	KConvert convert;
	std::vector<std::string> tokens;
	convert.storeTokens(args, tokens);

	double result = 1.0;

	for (const auto& str : tokens)
	{
		// 将字符串转换为整数  
		result *= std::stod(str);
	}

	return convert.doubleToChar(result);
}



//void myFunction() 
//{
//	// 获取函数的真正名称  
//	const std::type_info& info = typeid(sumFunction);
//	std::cout << "真正的函数名: " << info.name() << std::endl;
//
//	const std::type_info& info1 = typeid(powerFunction);
//	std::cout << "真正的函数名: " << info1.name() << std::endl;
//}
//
//int main() 
//{
//	myfunction();
//	//dumpbin / exports dllname.dll
//	return 0;
//}