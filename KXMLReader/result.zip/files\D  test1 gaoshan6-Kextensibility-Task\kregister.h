#ifndef KREGISTER_H_
#define KREGISTER_H_

//---------------------------------------------------------------------
//文件名:kregister.h
//创建者:高珊
//功能描述:注册类
//创建时间:2023/07/19
//Copyright 2023 Kingsoft
//---------------------------------------------------------------------

#include <iostream>
#include <map>
#include "kglobaldata.h"
#include <qstring.h>
#include <QObject>
#include <functional>
#include <qDebug>
#include <vector>
#include <Windows.h>
#include <stack>  
#include <sstream> 


class KRegister :public QObject
{
	Q_OBJECT

public:

	KRegister(QObject* parent = NULL);
	~KRegister();
	

	//注册内置函数
	void registerFunction(const QString& name, FunctionPtr func);
	//内部注册函数
	void registerFunction();
	//加载dll
	void registerDll();

	//解析表达式
	double calculate(const double& a, const double& b, const char& op);
	void parseExpression(const std::string& expression);
	void parseExpressionStr(const QString& expression);
	

public slots:
	void analyzeFunction();

signals:
	void finishResult();
	void finishRegister();
	void finishDllRegister();
};


class KFunctionCombiner
{
public:

	void addFunction(const QString& name, FunctionPtr func);
	
	FunctionPtr combineFunction(const QString& expression);
};

#endif