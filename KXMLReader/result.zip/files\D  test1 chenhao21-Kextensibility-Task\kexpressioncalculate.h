#ifndef KEXPRESSIONCALCULATE_H
#define KEXPRESSIONCALCULATE_H  
#include <QString>
#include <QStringList>
class KExpressionCalculate
{
public:
	double calculate(const QString& expression);
private:
	double evaluateFunc(const QString& expression);
	QString getFirstNumber(const QString& text) const;
	QString getFirstFunc(const QString& expression) const;
	double performOperation(double num1, double num2, char op);
	QStringList separateParams(const QString& paramsStr);
};

#endif // KEXPRESSIONCALCULATE_H  