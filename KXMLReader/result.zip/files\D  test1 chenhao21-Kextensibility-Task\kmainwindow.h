#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QPushButton>
#include <QListView>
#include <QTextEdit>
#include <QLineEdit>
#include <QLabel>
#include <QDebug>
#include <QStringListModel>

class KRegisterUi;
class KInnerRegister;
class KMainWindow : public QMainWindow
{
	Q_OBJECT

public:
	KMainWindow(QWidget* parent = nullptr);
	~KMainWindow();
private:
	void initUi();
	void addInnerFunc();
	void readIniFile();
private slots:
	void pressRegisterButton();
	void setFuncView();
	void setExpressionEdit(const QModelIndex &index);
	void pressExecuteBtn();
	void pressExecuteExpressionBtn();
	void pressLoadDllButton();

private:
	QPushButton* m_pLoadDllButton = nullptr;
	QPushButton* m_pRegisterButton = nullptr;
	QPushButton* m_pExecuteButton = nullptr;
	QPushButton* m_pExecuteExpressionButton = nullptr;
	QTextEdit* m_pExpressionEdit = nullptr;
	QLineEdit* m_pResultEdit = nullptr;
	QListView* m_pFuncView = nullptr;

	QLabel* m_pListLabel = nullptr;
	QLabel* m_pExpressionLabel = nullptr;
	QLabel* m_pResultLabel = nullptr;

	KRegisterUi* m_pRegisterWindow = nullptr;
	KInnerRegister* m_pInnerRegister = nullptr;
	QStringListModel* m_pModel = nullptr;
};
#endif // MAINWINDOW_H