#include "kregisterui.h"
#include "kouterregistermanager.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QStandardItemModel>
#include <QHeaderView>
KRegisterUi::KRegisterUi(QWidget* parent)
	: QDialog(parent)
{
	initUi();
	(void)connect(m_pComboBoxType, &QComboBox::currentTextChanged, this, &KRegisterUi::onTypeChanged);
	(void)connect(m_pEnterBtn, &QPushButton::clicked, this, &KRegisterUi::onEnterClicked);
	(void)connect(m_pCancelbtn, &QPushButton::clicked, this, &KRegisterUi::onCancelClicked);

}

void KRegisterUi::initUi()
{
	this->setFixedSize(540, 200);
	// 创建 Label 和 LineEdit
	m_pLabelName = new QLabel("Function Name:", this);
	m_pLabelName->setFixedWidth(95);
	m_pLineEditName = new QLineEdit(this);

	m_pLabelType = new QLabel("Function Type:", this);
	m_pLabelType->setFixedWidth(95);
	m_pComboBoxType = new QComboBox(this);
	m_pComboBoxType->addItem("Math Type");
	m_pComboBoxType->addItem("String Type");
	m_pComboBoxType->addItem("Self-definition Function");

	m_pLabelDescription = new QLabel("Description:", this);
	m_pLabelDescription->setFixedWidth(95);
	m_pLineEditDescription = new QLineEdit(this);

	m_pFuncExpression = new QTextEdit(this);
	m_pFuncExpression->hide();

	m_pEnterBtn = new QPushButton("Enter", this);
	m_pCancelbtn = new QPushButton("Cancel", this);

	// 创建垂直布局管理器
	m_pMainLayout = new QVBoxLayout(this);

	// 创建水平布局管理器
	m_pLayout1 = new QHBoxLayout(this);
	m_pLayout1->addWidget(m_pLabelName);
	m_pLayout1->addWidget(m_pLineEditName);

	m_pLayout2 = new QHBoxLayout(this);
	m_pLayout2->addWidget(m_pLabelType);
	m_pLayout2->addWidget(m_pComboBoxType);

	m_pLayout3 = new QHBoxLayout(this);
	m_pLayout3->addWidget(m_pLabelDescription);
	m_pLayout3->addWidget(m_pLineEditDescription);

	m_pSpacer = new QSpacerItem(250, 0, QSizePolicy::Minimum, QSizePolicy::Expanding);
	m_pLayout4 = new QHBoxLayout(this);
	m_pLayout4->addItem(m_pSpacer);
	m_pLayout4->addWidget(m_pEnterBtn);
	m_pLayout4->addWidget(m_pCancelbtn);

	m_pMainLayout->addLayout(m_pLayout1);
	m_pMainLayout->addLayout(m_pLayout2);
	m_pMainLayout->addLayout(m_pLayout3);
	m_pMainLayout->addWidget(m_pFuncExpression);
	m_pMainLayout->addLayout(m_pLayout4);

	setLayout(m_pMainLayout);
}

void KRegisterUi::onTypeChanged(const QString& text)
{
	if (text == "Self-definition Function")
	{
		m_pFuncExpression->show();
		this->setFixedSize(540, 345);
	}
	else
	{
		m_pFuncExpression->hide();
		this->setFixedSize(540, 200);
	}
}

void KRegisterUi::onEnterClicked()
{
	QString type = m_pComboBoxType->currentText();
	QString name = m_pLineEditName->text();
	KOuterRegisterManager* manager = KOuterRegisterManager::getInstance();
	if (type != "Self-definition Function")
	{
		manager->registerFuncInDlls(name, type);
//		if (manager->registerFuncInDlls(name, type))
//			qDebug() << "regist okok";
	}
	else
	{
		QString drescribe = m_pFuncExpression->toPlainText();
		manager->registerselfDefDrescription(name, type, drescribe);
	}
	emit registFuncUpdated();

}

void KRegisterUi::onCancelClicked()
{
	close();
}
