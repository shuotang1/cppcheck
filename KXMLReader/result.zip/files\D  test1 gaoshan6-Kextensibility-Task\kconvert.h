#ifndef KCONVERT_H_
#define KCONVERT_H_

#include <sstream>  
#include <cstring>  
#include <vector>

class KConvert
{
public:
	KConvert();
	~KConvert();

	//类型转换
	char* doubleToChar(double value);

	void storeTokens(const char* str, std::vector<std::string>& tokens);
private:
	char* charPtr;

};



#endif
