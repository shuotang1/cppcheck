#include "kfunction.h"
#include <qstring.h>
#include "kglobaldata.h"


KFunction::KFunction(QWidget* parent)
	:QWidget(parent),
	m_pVLayout(NULL),
	m_pFunctionLabel(NULL),
	m_pListView(NULL),
	m_pItemModel(NULL),
	m_pFunctionName(NULL),
	m_pFunctionNameList(NULL)
{
	m_pFunctionName.clear();
	m_pFunctionLabel = new QLabel(this);
	m_pFunctionLabel->setText("Function List");

	m_pListView = new QListView(this);
	m_pItemModel = new QStringListModel(this);
	m_pListView->setModel(m_pItemModel);
	
	m_pVLayout = new QVBoxLayout(this);
	m_pVLayout->setAlignment(Qt::AlignCenter | Qt::AlignTop);
	m_pVLayout->setSpacing(20);
	m_pVLayout->addWidget(m_pFunctionLabel);
	m_pVLayout->addWidget(m_pListView);

}

KFunction::~KFunction()//由主窗口释放
{

}

void KFunction::addNewFunction()
{
	m_pFunctionNameList.clear();
	m_pFunctionName= KGlobalData::getGlobalDataIntance()->getFunctionName();
	int count = 0;
	for (QVector<QString>::const_iterator it=m_pFunctionName.begin();it!=m_pFunctionName.end();++it)
	{
		count++;
		m_pFunctionNameList.push_back(*it);
	}
	std::cout << "count:" << count << std::endl;
	m_pItemModel->setStringList(m_pFunctionNameList);
	
}


void KFunction::onItemClicked(const QModelIndex& index)
{
	QString selectItem = index.data(Qt::DisplayRole).toString();
	selectItem += "(,)";
	KGlobalData::getGlobalDataIntance()->addExpression(selectItem);
	emit finishAddExpression();
}

