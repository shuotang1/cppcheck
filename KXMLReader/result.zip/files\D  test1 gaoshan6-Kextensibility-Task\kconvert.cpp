#include "kconvert.h"

KConvert::KConvert()
{

}
KConvert::~KConvert()
{
	delete charPtr;
}


char* KConvert::doubleToChar(double value)
{
	std::ostringstream oss;
	oss << value;
	std::string str = oss.str();
	char* charPtr = new char[str.length() + 1];
	strcpy_s(charPtr, str.length() + 1, str.c_str());
	return charPtr;
}

void KConvert::storeTokens(const char* str, std::vector<std::string>& tokens)
{
	char* context = nullptr;
	char* token = strtok_s(const_cast<char*>(str), " ", &context);
	while (token != nullptr)
	{
		tokens.push_back(token);
		token = strtok_s(nullptr, " ", &context);
	}
}