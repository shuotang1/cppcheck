#include "kinnerregister.h"
#include <QLibrary>
KInnerRegister::KInnerRegister()
{
}
KInnerRegister::~KInnerRegister()
{
	m_pInnerDll->unload();
	delete m_pInnerDll;
}
void KInnerRegister::initInner()
{
	if (m_pInnerDll == nullptr)
		m_pInnerDll = new QLibrary(INNER_DLL_PATH);
	if (m_pInnerDll == nullptr)
		return;
	if (!m_pInnerDll->load())
	{
//		qDebug() << "Open DLL failed";
		return;
	}


	VoidFuncPtr sumFunc = (VoidFuncPtr)m_pInnerDll->resolve("Sum");
	VoidFuncPtr powerFunc = (VoidFuncPtr)m_pInnerDll->resolve("Power");
	VoidFuncPtr averageFunc = (VoidFuncPtr)m_pInnerDll->resolve("Average");
	VoidFuncPtr combineFunc = (VoidFuncPtr)m_pInnerDll->resolve("Combine");

	KResourceSingleton* singleton = KResourceSingleton::getInstance();

	if (sumFunc != nullptr) 
	{
		singleton->addFunction("Sum", sumFunc);
		singleton->setInnerFuncType("Sum", "Math Type");
	}

	if (powerFunc != nullptr) 
	{
		singleton->addFunction("Power",powerFunc);
		singleton->setInnerFuncType("Power", "Math Type");
	}

	if (averageFunc != nullptr) 
	{
		singleton->addFunction("Average",averageFunc);
		singleton->setInnerFuncType("Average", "Math Type");
	}
	if (combineFunc != nullptr)
	{
		singleton->addFunction("Combine", combineFunc);
		singleton->setInnerFuncType("Combine", "String Type");
//		qDebug() << "combine ok";
	}
}