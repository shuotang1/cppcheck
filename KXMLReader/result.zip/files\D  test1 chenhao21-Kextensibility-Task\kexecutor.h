#ifndef KEXECUTOR_H  
#define KEXECUTOR_H  
#include <map>  
#include <functional>  
#include <string>  

class KExecutor
{
public:
	KExecutor();
	QString executehandle(const QString& input);
	double executeMath(const QString& input);
	double executeExpression(const QString& input);
	const QString executeString(const QString& input);
private:
	QStringList funcStringSplit(const QString& input, const QChar&);
	QString replaceChars(const QString& str, const QString& charsToReplace);
	QString replaceArg(const QString& str, const QStringList& list);

};

#endif // KEXECUTOR_H  