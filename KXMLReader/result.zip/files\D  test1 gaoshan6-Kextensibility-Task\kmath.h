#ifndef KMATH_H_
#define KMATH_H_

//---------------------------------------------------------------------
//文件名:kmath.h
//创建者:高珊
//功能描述:函数接口
//创建时间:2023/07/19
//Copyright 2023 Kingsoft
//---------------------------------------------------------------------

#include <iostream>
#include <qstring.h>
#include <vector>
#include <qdebug.h>
#include <string.h>
#include "kconvert.h"


class KMath
{
public:
	virtual ~KMath() {}
	virtual const char* getName() = 0;
	virtual char* exportFunction(const char* args) = 0;
};


class KSumFunction :public KMath
{
public:
	virtual const char* getName() override;
	char* exportFunction(const char* args)override;

private:
	double sum(std::vector<double>& nums);
};


class KAverageFunction :public KMath
{
public:
	virtual const char* getName() override;

	char* exportFunction(const char* args)override;

private:
	double average(std::vector<double>& nums);
};


class KPowerFunction :public KMath
{
public:
	virtual const char* getName() override;

	char* exportFunction(const char* args)override;
private:
	double multiplyAll(const std::vector<double>& nums);
	double power(double base, double count);
};


class KCombineStr :public KMath
{
public:

	virtual const char* getName() override;

	char* exportFunction(const char* args)override;
private:
	std::string combine(const std::vector<std::string>& strs);

};




//template<typename T,typename... Args>
//class KMath
//{
//public:
//	virtual QString getName()const = 0;
//	virtual T exportFunction(T arg,Args... args) = 0;
//};
//
//template<typename T, typename... Args>
//class SumFunction:public KMath
//{
//public:
//	QString getName()const override
//	{
//		QString str = "sum";
//		return str;
//	}
//	T exportFunction(T arg, Args... args)
//	{
//		return arg + sum(agrs...);
//	}
//
//private:
//	int sum()
//	{
//		return 0;
//	}
//		
//};
//
//template<typename T, typename... Args>
//class AverageFunction
//{
//public:
//	QString getName()const override
//	{
//		QString str = "average";
//		return str;
//	}
//	T exportFunction(T arg, Args... args)
//	{
//		return (arg + average(args...)) / (sizeof...(args) + 1);
//	}
//
//private:
//	double average()
//	{
//		return 0;
//	}
//};
//
//template<typename T, typename... Args>
//class PowerFunction
//{
//public:
//	QString getName()const override
//	{
//		QString str = "power";
//		return str;
//	}
//	T exportFunction(T arg, Args... args)
//	{
//		return power(arg, args...);
//	}
//private:
//	double power(T base,T exp)
//	{
//		if (exp == 0)
//			return 1;
//		else if (exp < 0)
//			return 1 / power(base, exp);
//		else
//			return base * power(base, exp - 1);
//	}
//};




#endif
