#include <QDebug>
#include <QString>
#include <QRegularExpressionMatchIterator>
#include "kresourcesingleton.h"
#include "kexecutor.h"  
#include "kexpressioncalculate.h"

KExecutor::KExecutor()
{
}
QString KExecutor::executehandle(const QString& input)
{
	QString str = replaceChars(input, "(),");
	QStringList strList = str.split(" ");
	QString functionName = strList.at(0);
	if (KResourceSingleton::getInstance()->isInnerFunc(functionName))
	{
		QString funcType = KResourceSingleton::getInstance()->getInnerFuncType(functionName);
		if (funcType == "Math Type")
		{
			return QString::number(executeMath(input));
		}
		if (funcType == "String Type")
		{
			return executeString(input);
		}
		/*if (funcType == "some inner func type")
		{

			InnerTypePtr funcptr = (InnerTypePtr)instance->getFunctionPointer(functionName);
			if (funcptr != nullptr)
				return funcptr(arg1, arg2...);

		}*/
	}
	if (KResourceSingleton::getInstance()->isOutFunc(functionName))
	{
		QString funcType = KResourceSingleton::getInstance()->getOuterFuncType(functionName);
		if (funcType == "Math Type")
		{
			return QString::number(executeMath(input));
		}
		if (funcType == "String Type")
		{
			return executeString(input);
		}
		if (funcType == "Self-definition Function")
		{
			return QString::number(executeExpression(input));
		}
	}
	return "";
}
double KExecutor::executeMath(const QString& input)
{
	QStringList strList = funcStringSplit(input, ' ');
	int argSize = strList.size() - 1;
	QString functionName = strList.at(0);
	double args[MAX_LENGTH];
	for (int i = 0; i < argSize && i< MAX_LENGTH; i++) 
	{
		args[i] = strList.at(i + 1).toDouble();
	}
	KResourceSingleton* instance = KResourceSingleton::getInstance();
	// 查找函数名对应的函数指针   
	MathFuncPtr funcptr = (MathFuncPtr)instance->getFunctionPointer(functionName);
//	qDebug() << functionName;
	if (funcptr != nullptr)
		return funcptr(args, argSize);
	else
		return 6666.6666;
}
double KExecutor::executeExpression(const QString& input)
{
	QStringList strList = funcStringSplit(input, ' ');
	int argSize = strList.size() - 1;
	QString functionName = strList.at(0);
	QString drescribe = KResourceSingleton::getInstance()->getSelfDefFuncDescription(functionName);

	drescribe = replaceArg(drescribe, strList.mid(1));
//	qDebug() << drescribe;
	KExpressionCalculate calculator;
	return calculator.calculate(drescribe);
}

const QString KExecutor::executeString(const QString& input)
{
	QStringList strList = funcStringSplit(input, '\"');
	int argSize = strList.size() - 1;
	QString functionName = strList.at(0);
	const char* args[MAX_LENGTH];
	for (int i = 0; i < argSize && i < MAX_LENGTH; i++)
	{
		QByteArray byteArray = strList.at(i + 1).toUtf8();
		char* charArray = new char[byteArray.size() + 1]; //后续释放内存delete[]
		strcpy_s(charArray, byteArray.size() + 1, byteArray.data());
		args[i] = charArray;  
	}
	KResourceSingleton* instance = KResourceSingleton::getInstance();
	// 查找函数名对应的函数指针   
	StringFuncPtr funcptr = (StringFuncPtr)instance->getFunctionPointer(functionName);
	char result[MAX_LENGTH];
	if(instance!=nullptr)
		funcptr(result, args, argSize);
	for (int i = 0; i < argSize && i < MAX_LENGTH; i++)
	{
		delete[] args[i];
		args[i] = nullptr;  //指针赋空值
	}
	return QString::fromUtf8(result);
}

QStringList KExecutor::funcStringSplit(const QString& input,const QChar& ch)
{
	QStringList result;

	QString functionName;
	QStringList arguments;

	int startIndex = input.indexOf('(');
	int endIndex = input.lastIndexOf(')');

	if (startIndex != -1 && endIndex != -1 && endIndex > startIndex)
	{
		functionName = input.left(startIndex).trimmed();

		QString argumentsString = input.mid(startIndex + 1, endIndex - startIndex - 1);
		arguments = argumentsString.split(',');

		for (QString& argument : arguments)
		{
			argument = argument.trimmed();
			argument.remove(ch);
		}
	}

	result.append(functionName);
	result.append(arguments);

	return result;
}

QString KExecutor::replaceChars(const QString& str, const QString& charsToReplace)
{
	QString result = str;
	for (QChar c : charsToReplace) {
		result.replace(c, ' ');
	}
	return result;
}
QString KExecutor::replaceArg(const QString& str, const QStringList& list)
{
	QString replacedStr = str;

	QRegularExpression regex("arg");

	int i = 0;
	int offset = 0;
	QRegularExpressionMatchIterator iter = regex.globalMatch(str);
	while (iter.hasNext() && i < list.size()) {
		QRegularExpressionMatch match = iter.next();
		int start = match.capturedStart() + offset;
		int length = match.capturedLength();
		replacedStr.replace(start, length, list.at(i++));
		offset += list.at(i - 1).length() - length;
	}

	return replacedStr;
}