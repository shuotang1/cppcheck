#include "kresult.h"
#include <qstring.h>
#include <QDebug>
#include "kglobaldata.h"

KResult::KResult(QWidget* parent)
	:QWidget(parent),
	m_pHLayout(NULL),
	m_pResultLabel(NULL),
	m_pResultEdit(NULL)
{
	m_pResultLabel = new QLabel(this);
	m_pResultLabel->setText("result");
	m_pResultLabel->setMaximumWidth(50);
	m_pResultEdit = new QLineEdit(this);
	m_pResultEdit->setMaximumWidth(800);
	m_pResultEdit->setMaximumHeight(20);

	m_pHLayout = new QHBoxLayout(this);
	m_pHLayout->setAlignment(Qt::AlignCenter | Qt::AlignTop);
	m_pHLayout->setSpacing(20);

	m_pHLayout->addWidget(m_pResultLabel);
	m_pHLayout->addWidget(m_pResultEdit);

}

KResult::~KResult()
{

}

void KResult::showResult()
{
	QString result = KGlobalData::getGlobalDataIntance()->getResult();
	qDebug() << "result:" << result;
	m_pResultEdit->setText(result);
}