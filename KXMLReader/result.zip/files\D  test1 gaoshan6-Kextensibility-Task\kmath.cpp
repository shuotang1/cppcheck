#include "kmath.h"


const char* KSumFunction::getName()
{
	const char* str = "sum";
	return str;
}
char* KSumFunction::exportFunction(const char* args)
{
	KConvert convert;
	std::vector<std::string> tokens;
	convert.storeTokens(args, tokens);

	std::vector<double> nums;
	for (const auto& str : tokens)
	{
		// 将字符串转换为整数  
		nums.push_back(std::stod(str));
	}

	double value = sum(nums);

	return convert.doubleToChar(value);
}
double KSumFunction::sum(std::vector<double>& nums)
{
	if (nums.empty())
		return 0;
	else
	{
		double num1 = nums[0];
		nums.erase(nums.begin());
		return num1 + sum(nums);
	}
}


const char* KAverageFunction::getName()
{
	const char* str = "average";
	return str;
}
char* KAverageFunction::exportFunction(const char* args)
{
	KConvert convert;
	std::vector<std::string> tokens;
	convert.storeTokens(args, tokens);
	std::vector<double> nums;
	for (const auto& str : tokens)
	{
		// 将字符串转换为整数  
		nums.push_back(std::stod(str));
	}
	int numberSize = nums.size();
	double value = average(nums)/numberSize;

	return convert.doubleToChar(value);
}
double KAverageFunction::average(std::vector<double>& nums)
{
	if (nums.empty())
		return 0;
	else
	{
		double num1 = nums[0];
		nums.erase(nums.begin());
		return num1 + average(nums);
	}
}


const char* KPowerFunction::getName()
{
	const char* str = "power";
	return str;
}
char* KPowerFunction::exportFunction(const char* args)
{
	KConvert convert;
	std::vector<std::string> tokens;
	convert.storeTokens(args, tokens);
	std::vector<double> nums;
	for (const auto& str : tokens)
	{
		// 将字符串转换为整数  
		nums.push_back(std::stod(str));
	}
	double base = nums[0];
	nums.erase(nums.begin());
	double count = multiplyAll(nums);

	double value = power(base, count);

	return convert.doubleToChar(value);
}
double KPowerFunction::multiplyAll(const std::vector<double>& nums)
{
	double result = 1;
	for (const double& num : nums) {
		result *= num;
	}
	return result;
}
double KPowerFunction::power(double base, double count)
{
	if (count == 0)
		return 1;
	else if (count < 0)
		return 1 / power(base, count);
	else
		return base * power(base, count - 1);
}


const char* KCombineStr::getName()
{
	const char* str = "combinestr";
	return str;
}
char* KCombineStr::exportFunction(const char* args)
{
	KConvert convert;
	std::vector<std::string> tokens;
	convert.storeTokens(args, tokens);
	std::string token=combine(tokens);

	char* charPtr = new char[token.length() + 1];
	strcpy_s(charPtr, token.length() + 1, token.c_str());
	return charPtr;
}
std::string KCombineStr::combine(const std::vector<std::string>& strs)
{
	std::string result = "";
	for (const std::string& str : strs)
	{
		result.append(str);
	}
	result.erase(std::remove(result.begin(), result.end(), '\"'), result.end());
	return result;
}