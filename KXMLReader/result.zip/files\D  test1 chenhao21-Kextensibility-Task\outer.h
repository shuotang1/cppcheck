#pragma once
#ifndef OUTER_H
#define OUTER_H

#ifdef OUTER_DLL
	#define OUTER_EXPORT extern "C" __declspec(dllexport)
#else
	#define OUTER_EXPORT __declspec(dllimport)
#endif
#define MAX_LENGTH 255

OUTER_EXPORT double OutMathFunc(double* args, int count);
OUTER_EXPORT bool OutStringFunc(char* dest, const char* src[], int count);
#endif //OUTER_H