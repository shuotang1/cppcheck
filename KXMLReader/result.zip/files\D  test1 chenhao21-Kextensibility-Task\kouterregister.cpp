#include "kouterregister.h"
KOuterRegister::KOuterRegister()
{
}
KOuterRegister::~KOuterRegister()
{
	m_phDll->unload();
	delete m_phDll;
}
KOuterRegister::KOuterRegister(const QString& path)
{
	m_phDll = new QLibrary(path);
}
bool KOuterRegister::loadDll()
{
	if (!m_phDll->load()) 
	{
//		qDebug() << "Open DLL failed";
		return false;
	}
	return true;
}
bool KOuterRegister::registerFunc(const QString& funcName, const QString& funcType)
{
	VoidFuncPtr func = (VoidFuncPtr)m_phDll->resolve(funcName.toStdString().c_str());
	if (func == nullptr)
		return false;
	KResourceSingleton* singleton = KResourceSingleton::getInstance();
	singleton->addFunction(funcName, (void(*)())func);
	singleton->setOuterFuncType(funcName, funcType);
	
	return true;
}

