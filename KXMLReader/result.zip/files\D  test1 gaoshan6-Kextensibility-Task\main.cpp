#include <QApplication>  
#include "kmainwindow.h"  
#include <vld.h>

int main(int argc, char* argv[])
{
	QApplication a(argc, argv);

	KMainWindow mainWindow;
	mainWindow.show();

	return a.exec();
}