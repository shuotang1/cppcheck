#include "kbutton.h"

KButton::KButton(QWidget* parent)
	:QWidget(parent),
	m_pHLayout(NULL),
	m_pFuncButton(NULL),
	m_pAddinButton(NULL),
	m_pExecuteButtton(NULL)
{
	m_pFuncButton = new QPushButton(this);
	m_pFuncButton->setText("RejisterFunc");
	m_pAddinButton = new QPushButton(this);
	m_pAddinButton->setText("RejesterAddin");
	m_pExecuteButtton = new QPushButton(this);
	m_pExecuteButtton->setText("Excute");

	m_pHLayout = new QHBoxLayout(this);
	m_pHLayout->setAlignment(Qt::AlignCenter | Qt::AlignTop);
	m_pHLayout->setSpacing(20);

	m_pHLayout->addWidget(m_pFuncButton);
	m_pHLayout->addWidget(m_pAddinButton);
	m_pHLayout->addWidget(m_pExecuteButtton);

}

KButton::~KButton()
{

}