#include "kdialog.h"


KDialog::KDialog(QWidget* parent)
	:QDialog(parent),
	m_pName(NULL),
	m_pNameEdit(NULL),
	m_pType(NULL),
	m_pTypeBox(NULL),
	m_pDescription(NULL),
	m_pDescriptionEdit(NULL),
	m_pCount(NULL),
	m_pCountChange(NULL),
	m_pTableWidget(NULL),
	m_pFLayout(NULL),
	m_pOkButton(NULL),
	m_pCancelButton(NULL),
	m_pButtonLayout(NULL),
	m_pExpressionLabel(NULL),
	m_pExpressionEdite(NULL),
	m_pVLayout(NULL),
	m_pNameItem(NULL),
	m_pTypeItem(NULL),
	m_pDescriptionItem(NULL),
	m_pCountItem(NULL),
	m_tableRow(1),
	m_tableColumn(4)
{
	m_pName = new QLabel(this);
	m_pName->setText("Function Name");
	m_pType = new QLabel(this);
	m_pType->setText("Result Type");
	m_pDescription = new QLabel(this);
	m_pDescription->setText("Description");
	m_pCount = new QLabel(this);
	m_pCount->setText("Argument Count");

	m_pNameEdit = new QLineEdit(this);
	m_pTypeBox = new QComboBox(this);
	m_pTypeBox->addItem("int");
	m_pTypeBox->addItem("double");
	m_pTypeBox->addItem("string");
	m_pDescriptionEdit = new QLineEdit(this);
	m_pCountChange = new QSpinBox(this);
	m_pCountChange->setRange(2, 255);
	m_pCountChange->setValue(2);

	
	m_pFLayout = new QFormLayout;
	m_pFLayout->addRow(m_pName,m_pNameEdit);
	m_pFLayout->addRow(m_pType,m_pTypeBox);
	m_pFLayout->addRow(m_pDescription,m_pDescriptionEdit);
	m_pFLayout->addRow(m_pCount,m_pCountChange);

	m_pTableWidget = new QTableWidget(this);
	initTableWidget();

	m_pExpressionLabel = new QLabel(this);
	m_pExpressionLabel->setText("Expression");
	m_pExpressionEdite = new QTextEdit(this);



	m_pOkButton = new QPushButton(this);
	m_pOkButton->setText("Ok");
	m_pCancelButton = new QPushButton(this);
	m_pCancelButton->setText("Cancel");
	m_pButtonLayout = new QHBoxLayout;
	m_pButtonLayout->addWidget(m_pOkButton);
	m_pButtonLayout->addWidget(m_pCancelButton);

	m_pVLayout = new QVBoxLayout(this);

	m_pVLayout->addLayout(m_pFLayout);
	m_pVLayout->addWidget(m_pTableWidget);
	m_pVLayout->addWidget(m_pExpressionLabel);
	m_pVLayout->addWidget(m_pExpressionEdite);
	m_pVLayout->addLayout(m_pButtonLayout);


}
KDialog::~KDialog()
{
	delete m_pButtonLayout;
	delete m_pFLayout;
	delete m_pNameItem;
	delete m_pTypeItem;
	delete m_pDescriptionItem;
	delete m_pCountItem;
}

void KDialog::initTableWidget()
{
	m_pTableWidget->setRowCount(m_tableRow);
	m_pTableWidget->setColumnCount(m_tableColumn);
	QStringList headerLabels;
	headerLabels << "Name" << "Type" << "Description"<<"Count";
	m_pTableWidget->setHorizontalHeaderLabels(headerLabels);

}

void KDialog::setInformation()
{
	KGlobalData::getGlobalDataIntance()->setAddFunctionName(m_pNameEdit->text());
	KGlobalData::getGlobalDataIntance()->setFunctionType(m_pTypeBox->currentText());
	KGlobalData::getGlobalDataIntance()->setDescription(m_pDescriptionEdit->text());
	KGlobalData::getGlobalDataIntance()->setCount(m_pCountChange->value());
	KGlobalData::getGlobalDataIntance()->setExpression(m_pExpressionEdite->toPlainText());
	emit finishInformation();
}

void KDialog::showTableWidget()
{
	m_pNameItem = new QTableWidgetItem(m_pNameEdit->text());
	m_pTypeItem = new QTableWidgetItem(m_pTypeBox->currentText());
	m_pDescriptionItem = new QTableWidgetItem(m_pDescriptionEdit->text());
	m_pCountItem = new QTableWidgetItem(QString::number(m_pCountChange->value()));
	qDebug() << "count:" << m_pCountChange->value();

	m_pTableWidget->setItem(0, 0, m_pNameItem);
	m_pTableWidget->setItem(0, 1, m_pTypeItem);
	m_pTableWidget->setItem(0, 2, m_pDescriptionItem);
	m_pTableWidget->setItem(0, 3, m_pCountItem);
}