#pragma once
#ifndef INNER_H
#define INNER_H

#ifdef INNER_DLL
	#define INNER_EXPORT extern "C" __declspec(dllexport)
#else
	#define INNER_EXPORT __declspec(dllimport)
#endif
#define MAX_LENGTH 255

INNER_EXPORT double Sum(double* args, int count);
INNER_EXPORT double Power(double* args, int count);
INNER_EXPORT double Average(double* args, int count);

INNER_EXPORT bool Combine(char* dest, const char* src[], int count);
#endif //INNER_H