#ifndef KREGISTERMANGER_H
#define KREGISTERMANGER_H

#include <QLibrary>
#include <QDebug>
#include <QVector>
#include <QString>
#include "kresourcesingleton.h"
#include "kouterregister.h"

class KOuterRegisterManager
{
public:
	static KOuterRegisterManager* getInstance();

	void addRegister(const QString& path);
	void loadAllDll();
	bool registerFuncInDlls(const QString& funcName, const QString& funcType);
	bool registerselfDefDrescription(const QString& funcName, const QString& funcType, const QString& selfDefDrescription);
	void parseIniFile(const QString& filePath);

private:
	KOuterRegisterManager();
	~KOuterRegisterManager();
	KOuterRegisterManager(const KOuterRegisterManager &) = delete;
	KOuterRegisterManager &operator=(const KOuterRegisterManager &) = delete;
private:
	static KOuterRegisterManager* s_pInstance;
	QVector<KOuterRegister*> m_pRegisterVrc;
};



#endif //KREGISTERMANGER_H
