#ifndef KBUTTON_H_
#define KBUTTON_H_

//---------------------------------------------------------------------
//文件名:kbutton.h
//创建者:高珊
//功能描述:主界面按钮组件
//创建时间:2023/07/19
//Copyright 2023 Kingsoft
//---------------------------------------------------------------------

#include <qlayout.h>
#include <QtWidgets/QMainWindow>
#include <qpushbutton.h>

class KButton :public QWidget
{
	Q_OBJECT

public:
	KButton(QWidget* parent);
	~KButton();

	QHBoxLayout* m_pHLayout;
	QPushButton* m_pFuncButton;
	QPushButton* m_pAddinButton;
	QPushButton* m_pExecuteButtton;
};

#endif