#ifndef KDIALOG_H_
#define KDIALOG_H_

//---------------------------------------------------------------------
//文件名:kdialog.h
//创建者:高珊
//功能描述:自定义函数窗口
//创建时间:2023/07/19
//Copyright 2023 Kingsoft
//---------------------------------------------------------------------

#include <QMainWindow>
#include <qlabel.h>
#include <qlineedit.h>
#include <QComboBox>
#include <QSpinBox>
#include <qlayout.h>
#include <QDialog>  
#include <QFormLayout>
#include <qstring.h>
#include <qpushbutton.h>
#include <QTableWidget>
#include <qtextedit.h>
#include <qdebug.h>
#include "kglobaldata.h"



class KDialog :public QDialog
{
	Q_OBJECT
public:
	KDialog(QWidget* parent=NULL);
	~KDialog();


	void initTableWidget();

public slots:
	void setInformation();
	void showTableWidget();
signals:
	void finishInformation();

public:
	QLabel* m_pName;
	QLabel* m_pType;
	QLabel* m_pDescription;
	QLabel* m_pCount;

	QLineEdit* m_pNameEdit;
	QComboBox* m_pTypeBox;
	QLineEdit* m_pDescriptionEdit;
	QSpinBox* m_pCountChange;
	QFormLayout* m_pFLayout;

	QTableWidget* m_pTableWidget;
	int m_tableRow;
	int m_tableColumn;

	
	QPushButton* m_pOkButton;
	QPushButton* m_pCancelButton;
	QHBoxLayout* m_pButtonLayout;

	QLabel* m_pExpressionLabel;
	QTextEdit* m_pExpressionEdite;//表达式输入

	QVBoxLayout* m_pVLayout;


	QTableWidgetItem* m_pNameItem;
	QTableWidgetItem* m_pTypeItem;
	QTableWidgetItem* m_pDescriptionItem;
	QTableWidgetItem* m_pCountItem;
};
#endif