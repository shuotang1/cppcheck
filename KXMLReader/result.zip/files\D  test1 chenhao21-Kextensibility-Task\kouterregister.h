#ifndef KREGISTER_H
#define KREGISTER_H

#include <QLibrary>
#include <QDebug>
#include "kresourcesingleton.h"

class KOuterRegister// : public  QObject
{
public:
	KOuterRegister();
	~KOuterRegister();
	KOuterRegister(const QString& path);
	bool loadDll();
	bool registerFunc(const QString& funcName, const QString& funcType);

private:
	QLibrary* m_phDll = nullptr;
};


#endif //KREGISTER_H
