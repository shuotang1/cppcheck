#include "kmainwindow.h"
//#include "mathfunction.h"
#include <qvector.h>
#include <qdebug.h>
#include <fstream>


KMainWindow::KMainWindow(QWidget* parent)
	:QMainWindow(parent),
	m_pCenterWidget(NULL),
	m_pVLayout1(NULL),
	m_pVLayout2(NULL),
	m_pHLayout(NULL),
	m_pRegister(NULL),
	m_pFunction(NULL),
	m_pExpression(NULL),
	m_pResult(NULL),
	m_pButton(NULL),
	m_pDialog(NULL),
	m_pFileDialog(NULL),
	m_pSumFunction(NULL),
	m_pAverageFunction(NULL),
	m_pPowerFunction(NULL),
	m_pCombineStrFunction(NULL)
{
	/*初始化界面*/
	initWindows();
	(void)connect(this, &KMainWindow::addInitFunction, m_pFunction, &KFunction::addNewFunction);
	initFunction();

	//(void)connect(m_pFunction->m_pListWidget, &QListWidget::itemDoubleClicked, m_pFunction, &KFunction::onItemDoubleClicked);//组件使用错误换QListView
	(void)connect(m_pFunction->m_pListView, &QListView::clicked, m_pFunction, &KFunction::onItemClicked);
	(void)connect(m_pFunction, &KFunction::finishAddExpression, m_pExpression, &KExpression::updateExpression);
	
	/*表达式*/
	(void)connect(m_pButton->m_pExecuteButtton, &QPushButton::clicked, m_pExpression,&KExpression::saveExpression);
	(void)connect(m_pExpression, &KExpression::finishExpression, m_pRegister, &KRegister::analyzeFunction);//解析
	(void)connect(m_pRegister, &KRegister::finishResult, m_pResult, &KResult::showResult);


	/*注册函数*/
	m_pDialog = new KDialog(this);
	(void)connect(m_pDialog->m_pCancelButton, &QPushButton::clicked, this, &KMainWindow::choseDialog);//取消注册
	(void)connect(m_pButton->m_pFuncButton, &QPushButton::clicked, this, &KMainWindow::openDialog);
	(void)connect(m_pDialog->m_pOkButton, &QPushButton::clicked, m_pDialog, &KDialog::setInformation);
	(void)connect(m_pDialog, &KDialog::finishInformation, m_pDialog, &KDialog::showTableWidget);
	void (KRegister:: *registerPtr)() = &KRegister::registerFunction;
	(void)connect(m_pDialog, &KDialog::finishInformation, m_pRegister, registerPtr);
	(void)connect(m_pRegister, &KRegister::finishRegister, m_pFunction, &KFunction::addNewFunction);
	

	/*加载dll*/
	m_pFileDialog = new QFileDialog(this);
	(void)connect(m_pButton->m_pAddinButton, &QPushButton::clicked, this, &KMainWindow::openFileDialog);
	(void)connect(this, &KMainWindow::startAnalyze, this, &KMainWindow::analyzeIni);
	(void)connect(this, &KMainWindow::finishIni, m_pRegister, &KRegister::registerDll);
	(void)connect(m_pRegister, &KRegister::finishDllRegister, m_pFunction, &KFunction::addNewFunction);

}


KMainWindow::~KMainWindow()
{
	delete m_pSumFunction;
	delete m_pAverageFunction;
	delete m_pPowerFunction;
	delete m_pCombineStrFunction;
}


void KMainWindow::initWindows()
{
	m_pCenterWidget = new QWidget(this);
	m_pHLayout = new QHBoxLayout(this);
	m_pHLayout->setSpacing(0);
	m_pHLayout->setMargin(0);//离原点的距离
	m_pVLayout1 = new QVBoxLayout(this);
	m_pVLayout2 = new QVBoxLayout(this);

	m_pFunction = new KFunction(this);
	m_pExpression = new KExpression(this);
	m_pResult = new KResult(this);
	m_pButton = new KButton(this);

	m_pVLayout1->addWidget(m_pExpression);
	m_pVLayout1->addWidget(m_pResult);
	m_pVLayout1->addWidget(m_pButton);
	m_pVLayout2->addWidget(m_pFunction);

	m_pHLayout->addLayout(m_pVLayout2);
	m_pHLayout->addLayout(m_pVLayout1);

	m_pCenterWidget->setLayout(m_pHLayout);
	this->setCentralWidget(m_pCenterWidget);
}


void KMainWindow::initFunction()
{
	//将内置函数启动时注册
	m_pRegister = new KRegister(this);
	m_pSumFunction = new KSumFunction;
	m_pAverageFunction = new KAverageFunction;
	m_pPowerFunction = new KPowerFunction;
	m_pCombineStrFunction = new KCombineStr;

	m_pRegister->registerFunction(QString::fromStdString(m_pSumFunction->getName()), m_pSumFunction);
	m_pRegister->registerFunction(QString::fromStdString(m_pAverageFunction->getName()), m_pAverageFunction);
	m_pRegister->registerFunction(QString::fromStdString(m_pPowerFunction->getName()), m_pPowerFunction);
	m_pRegister->registerFunction(QString::fromStdString(m_pCombineStrFunction->getName()), m_pCombineStrFunction);
	

	KGlobalData::getGlobalDataIntance()->setFunctionName(QString::fromStdString(m_pSumFunction->getName()));
	KGlobalData::getGlobalDataIntance()->setFunctionName(QString::fromStdString(m_pAverageFunction->getName()));
	KGlobalData::getGlobalDataIntance()->setFunctionName(QString::fromStdString(m_pPowerFunction->getName()));
	KGlobalData::getGlobalDataIntance()->setFunctionName(QString::fromStdString(m_pCombineStrFunction->getName()));


	emit addInitFunction();
}



void KMainWindow::openDialog()
{
	m_pDialog->setFixedSize(400, 300);
	m_pDialog->exec();
}


void KMainWindow::choseDialog()
{
	m_pDialog->accept();
}

void KMainWindow::openFileDialog()
{
	QString filePath = m_pFileDialog->getOpenFileName(this, "Open File", "", "All Files (*.*)");
	KGlobalData::getGlobalDataIntance()->setDllAddress(filePath);
	emit startAnalyze();
}

void KMainWindow::analyzeIni()
{
	std::ifstream configFile("mydll.ini");//dll配置文件，保存函数名，函数返回值，返回类型，参数、地址等信息，但是地址可以通过直接选择
	if (configFile.is_open())
	{
		std::string line;
		std::map<std::string, std::map<std::string, std::string>>configData;
		std::string currentSection;

		while (std::getline(configFile, line))
		{
			if (line.length() > 0)
			{
				//std::cout << line<<std::endl;
				if (line[0] == '[' && line[line.length() - 1] == ']')
				{
					currentSection = line.substr(1, line.length() - 2);
					//std::cout<<currentSection;
				}
				else
				{
					size_t delimiterPos = line.find('=');
					if (delimiterPos != std::string::npos)
					{
						std::string key = line.substr(0, delimiterPos);
						std::string value = line.substr(delimiterPos + 1);
						configData[currentSection][key] = value;
					}
				}
			}
		}
		configFile.close();
		KGlobalData::getGlobalDataIntance()->setDllFunction(configData);
	}
	
	emit finishIni();

}