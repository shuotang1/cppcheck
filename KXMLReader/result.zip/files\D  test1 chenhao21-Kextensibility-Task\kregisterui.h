#ifndef KREGISTERUI_H
#define KREGISTERUI_H

#include <QDialog>
#include <QLabel>
#include <QLineEdit>
#include <QTextEdit>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QComboBox>
#include <QPushButton>

#include "kresourcesingleton.h"

class KRegisterUi : public QDialog
{
	Q_OBJECT

public:
	KRegisterUi(QWidget* parent = nullptr);
private:
	void initUi();
signals:
	void registFuncUpdated();
private slots:
	void onTypeChanged(const QString& text);
	void onEnterClicked();
	void onCancelClicked();

private:
	QVBoxLayout *m_pMainLayout = nullptr;

	QHBoxLayout *m_pLayout1 = nullptr;
	QLabel* m_pLabelName = nullptr;
	QLineEdit* m_pLineEditName = nullptr;

	QHBoxLayout *m_pLayout2 = nullptr;
	QLabel* m_pLabelType = nullptr;
	QComboBox* m_pComboBoxType = nullptr;

	QHBoxLayout *m_pLayout3 = nullptr;
	QLabel* m_pLabelDescription = nullptr;
	QLineEdit* m_pLineEditDescription = nullptr;

	QTextEdit* m_pFuncExpression = nullptr;

	QHBoxLayout *m_pLayout4 = nullptr;
	QPushButton* m_pEnterBtn = nullptr;
	QPushButton* m_pCancelbtn = nullptr;
	QSpacerItem* m_pSpacer = nullptr;

};

#endif //KREGISTERUI_H
