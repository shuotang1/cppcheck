#include "kglobaldata.h"

KGlobalData* KGlobalData::s_globalDataObj = NULL;
KGlobalData::KRelease KGlobalData::s_gc;

KGlobalData::KGlobalData()
{
	m_functionName = {};
	m_expression = "";
	m_result = "";
	m_addFunctionName = "";
	m_functionType = "";
	m_description = "";
	m_count = 0;
	m_dllAddress = "";
	m_configData = {};
	m_functionMap = {};
}

KGlobalData::~KGlobalData()
{
	
}

KGlobalData* KGlobalData::getGlobalDataIntance()
{
	if (s_globalDataObj == NULL)
		s_globalDataObj = new KGlobalData;
	return s_globalDataObj;
}


QVector<QString> KGlobalData::getFunctionName()
{
	return m_functionName;
}
void KGlobalData::setFunctionName(const QString& functionName)
{
	m_functionName.push_back(functionName);
}


QString KGlobalData::getExpression()
{
	return m_expression;
}
void KGlobalData::setExpression(const QString& expression)
{
	m_expression = expression;
}
void KGlobalData::addExpression(const QString& expression)
{
	m_expression = "";
	m_expression += expression;
}


QString KGlobalData::getResult()
{
	return m_result;
}
void KGlobalData::setResult(const QString& result)
{
	m_result = result;
}

QString KGlobalData::getAddFunctionName()
{
	return m_addFunctionName;
}
void KGlobalData::setAddFunctionName(const QString& addFunctionName)
{
	m_addFunctionName = addFunctionName;
}


QString KGlobalData::getFunctionType()
{
	return m_functionType;
}
void KGlobalData::setFunctionType(const QString& type)
{
	m_functionType = type;
}

QString KGlobalData::getDescription()
{
	return m_description;
}
void KGlobalData::setDescription(const QString& description)
{
	m_description = description;
}

int KGlobalData::getCount()
{
	return m_count;
}
void KGlobalData::setCount(const int& count)
{
	m_count = count;
}

QString KGlobalData::getDllAddress()
{
	return m_dllAddress;
}
void KGlobalData::setDllAddress(const QString& dllAddress)
{
	m_dllAddress = dllAddress;
}

std::map<std::string, std::map<std::string, std::string>> KGlobalData::getDllFunction()
{
	return m_configData;
}
void KGlobalData::setDllFunction(const std::map<std::string, std::map<std::string, std::string>>& configData)
{
	m_configData = configData;
}


std::map<QString, FunctionPtr> KGlobalData::getFunctionMap()
{
	return m_functionMap;
}
void KGlobalData::setFunctionMap(const QString& name, FunctionPtr func)
{
	m_functionMap[name] = func;
}