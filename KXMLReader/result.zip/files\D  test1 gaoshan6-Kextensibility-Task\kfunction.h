#ifndef KFUNCTION_H_
#define  KFUNCTION_H_

//---------------------------------------------------------------------
//文件名:kfunction.h
//创建者:高珊
//功能描述:最左侧功能函数组件
//创建时间:2023/07/19
//Copyright 2023 Kingsoft
//---------------------------------------------------------------------

#include <qvector.h>
#include <QtWidgets/QMainWindow>
#include <qlayout.h>
#include <qlabel.h>
#include <qlineedit.h>
#include <QListWidget>
#include <QListView>
#include <QStringListModel>

class KFunction :public QWidget
{
	Q_OBJECT
public:
	KFunction(QWidget* parent);
	~KFunction();


public slots:
	void addNewFunction();//增加功能
	void onItemClicked(const QModelIndex& index);

signals:
	void finishAddExpression();

public:
	QVBoxLayout* m_pVLayout;//垂直布局
	QLabel* m_pFunctionLabel;//功能标题

	QListView* m_pListView;//功能列表
	QStringListModel* m_pItemModel;

private:
	QVector<QString> m_pFunctionName;
	QStringList m_pFunctionNameList;
};

#endif