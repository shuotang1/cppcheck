#include "kexpression.h"
#include <qstring.h>
#include "kglobaldata.h"

KExpression::KExpression(QWidget* parent)
	:QWidget(parent),
	m_pVLayout(NULL),
	m_pExpressionLabel(NULL),
	m_pExpressionEdite(NULL)
{
	m_pExpressionLabel = new QLabel(this);
	m_pExpressionLabel->setText("Expression");

	m_pExpressionEdite = new QTextEdit(this);
	//m_pExpressionEdite->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);

	m_pVLayout = new QVBoxLayout(this);
	m_pVLayout->setAlignment(Qt::AlignCenter | Qt::AlignTop);
	m_pVLayout->setSpacing(20);
	m_pVLayout->addWidget(m_pExpressionLabel);
	m_pVLayout->addWidget(m_pExpressionEdite);

}

KExpression::~KExpression()
{
	
}

void KExpression::saveExpression()
{
	QString text = m_pExpressionEdite->toPlainText();
	KGlobalData::getGlobalDataIntance()->setExpression(text);
	emit finishExpression();
}

void KExpression::updateExpression()
{
	QString text = KGlobalData::getGlobalDataIntance()->getExpression();
	m_pExpressionEdite->setText(text);
}